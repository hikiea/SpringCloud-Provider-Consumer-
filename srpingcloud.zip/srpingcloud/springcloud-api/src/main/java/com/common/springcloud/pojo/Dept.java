package com.common.springcloud.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import java.io.Serializable;

@Data // 用注解的方式实现Get和Set
@NoArgsConstructor // 生成一个无参数的构造方法
@Accessors(chain = true)    // 支持链式写法，下方讲解

//实现序列化的目的是为了保证流传输不出问题
public class Dept implements Serializable {
    private long deptno;    //主键
    private String dname;
    private  String db_source;
}

/**
 * 链式写法
 * dept.setDeptNo(11).setDname('sss').setDb_source()
 */
