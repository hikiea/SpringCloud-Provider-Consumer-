package com.common.springcloud.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
// 调用网络请求模板:RestTemplate,进行网络请求
public class configBean {
    @Bean
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }
}
