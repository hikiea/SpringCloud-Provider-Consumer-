package com.common.springcloud.controller;

import com.common.springcloud.pojo.Dept;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
public class DeptConsumerController {

    // 理解：消费者，不应该有server层
    // 使用RestTemplate获取provider提供的数据

    // springboot中的一种网络请求：RestTemplate
    //核心参数（ url , 实体：Map , class<T> responseType(返回值.class) ）
    @Autowired
    private RestTemplate restTemplate; //提供多种便捷访问远程http服务的方法，一种简单的restful服务模板

    private static final String REST_URL_PREDIX = "http://localhost:8002";

    // 服务器端给你什么方法就用什么方法 给你 "/dept/list" ,就在网络请求方法里面调用 "/dept/list"
    @RequestMapping("/consumer/dept/list")
    public List<Dept> list(){
        return restTemplate.getForObject(REST_URL_PREDIX + "/dept/list", List.class);
    }

    @RequestMapping("/consumer/dept/add")
    public boolean add(Dept dept){
        return restTemplate.postForObject(REST_URL_PREDIX + "/dept/add",dept,Boolean.class );
    }


    @RequestMapping("/consumer/dept/get/{id}")
    public Dept get(@PathVariable("id") Integer id){
        return restTemplate.getForObject(REST_URL_PREDIX + "/dept/get/" + id ,Dept.class);
    }

}
