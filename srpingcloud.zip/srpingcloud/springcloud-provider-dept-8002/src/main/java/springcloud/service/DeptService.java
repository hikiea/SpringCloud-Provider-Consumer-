package springcloud.service;

import com.common.springcloud.pojo.Dept;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import springcloud.mapper.DeptDao;

import java.util.List;

@Service
public class DeptService {

    @Autowired
    private DeptDao deptDao;

    public boolean addDept(Dept dept) {
        return deptDao.addDept(dept);
    }

    public Dept queryId(Integer id) {
        return deptDao.queryId(id);
    }

    public List<Dept> queryAll() {
        return deptDao.queryAll();
    }
}
